#ifndef _NGX_STREAME_LUA_PHASE_H_INCLUDED_
#define _NGX_STREAME_LUA_PHASE_H_INCLUDED_


#include "ngx_stream_lua_common.h"


void ngx_stream_lua_inject_phase_api(lua_State *L);


#endif /* _NGX_STREAME_LUA_PHASE_H_INCLUDED_ */
